return
{
	vertices = {
		{ position = { 0.772727, 11.0606, 0 } },
		{ position = { -0.772727, 11.0606, 0 } },
		{ position = { -0.651515, 6.51515, 0 } },
		{ position = { 0.666667, 6.51515, 0 } },
	},
	indices = {
		0, 2, 3, 1, 2, 0
	}
}

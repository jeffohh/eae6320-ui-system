return
{
	vertices = {
		{ position = { 3.63636, -0.378788, 0 } },
		{ position = { -3.63636, -0.378788, 0 } },
		{ position = { -3.63636, -1.51515, 0 } },
		{ position = { 3.63636, -1.51515, 0 } },
	},
	indices = {
		0, 1, 3, 3, 1, 2
	}
}

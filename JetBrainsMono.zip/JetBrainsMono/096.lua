return
{
	vertices = {
		{ position = { -0.075758, 11.8939, 0 } },
		{ position = { -1.59091, 11.8939, 0 } },
		{ position = { 0.151515, 9.77273, 0 } },
		{ position = { 1.59091, 9.77273, 0 } },
	},
	indices = {
		0, 2, 3, 1, 2, 0
	}
}

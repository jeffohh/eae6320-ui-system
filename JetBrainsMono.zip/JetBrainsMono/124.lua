return
{
	vertices = {
		{ position = { 0.681818, 12.5758, 0 } },
		{ position = { -0.681818, 12.5758, 0 } },
		{ position = { -0.681818, -1.66667, 0 } },
		{ position = { 0.681818, -1.66667, 0 } },
	},
	indices = {
		0, 1, 3, 3, 1, 2
	}
}

return
{
	vertices = {
		{ position = { 3.40909, 12.5758, 0 } },
		{ position = { 1.9697, 12.5758, 0 } },
		{ position = { -3.40909, -1.66667, 0 } },
		{ position = { -1.9697, -1.66667, 0 } },
	},
	indices = {
		0, 1, 3, 3, 1, 2
	}
}

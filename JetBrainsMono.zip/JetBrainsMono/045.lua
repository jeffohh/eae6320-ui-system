return
{
	vertices = {
		{ position = { 2.42424, 5.60606, 0 } },
		{ position = { -2.42424, 5.60606, 0 } },
		{ position = { -2.42424, 4.39394, 0 } },
		{ position = { 2.42424, 4.39394, 0 } },
	},
	indices = {
		0, 1, 3, 3, 1, 2
	}
}

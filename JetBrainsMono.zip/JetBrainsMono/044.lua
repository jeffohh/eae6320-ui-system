return
{
	vertices = {
		{ position = { 1.23485, 2.21212, 0 } },
		{ position = { -0.401515, 2.21212, 0 } },
		{ position = { -1.23485, -2.42424, 0 } },
		{ position = { 0.174242, -2.42424, 0 } },
	},
	indices = {
		0, 1, 3, 3, 1, 2
	}
}
